/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebatecnica;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author nicolaseduardoperalta
 */
public class B {
     public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el tamaño de la matriz");
        int tamano= scanner.nextInt();
        while (tamano < 0 || tamano >= 100000) {
            System.out.println("Tamaño incorrecto");
            tamano= scanner.nextInt();
        }
        int suma = 0;        
        int[][] cadena = new int[tamano][tamano]; 
        
        for (int i = 0; i < tamano; i++){
            for (int j = 0; j < tamano; j++){
                if (j == (tamano - 1 - i)){
                    cadena[i][j]=(tamano-j);
                    suma += (tamano-j);
                }else if(j > (tamano - 1 - i)){
                    cadena[i][j]=0;
                }else{
                    cadena[i][j]=1;
                }
            }
        }
        
        for (int i = 0; i < tamano; i++){
            for (int j = 0; j < tamano; j++){
                System.out.print(cadena[j][i] + " ");
            }
            System.out.println();
        }
        System.out.println(suma);
        scanner.close();
    }
}
