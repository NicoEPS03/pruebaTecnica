/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebatecnica;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author nicolaseduardoperalta
 */
public class A {
     public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        StringTokenizer cadena1, cadena2;
        System.out.println("Ingrese las primeras coordenadas");
        cadena1 = new StringTokenizer(scanner.nextLine());
        float x1, x2, y1, y2;
        int z1, z2;

        x1 = Float.parseFloat(cadena1.nextToken());
        y1 = Float.parseFloat(cadena1.nextToken());
        z1 = Integer.parseInt(cadena1.nextToken());
        while ((x1 <= -100000 || x1 >= 100000) || (y1 <= -100000 || y1 >= 100000) || (z1 < 0 || z1 >= 100000)) {
            System.out.println("Coordenadas incorrectas, vuelva a ingresar");
            cadena1 = new StringTokenizer(scanner.nextLine());

            x1 = Float.parseFloat(cadena1.nextToken());
            y1 = Float.parseFloat(cadena1.nextToken());
            z1 = Integer.parseInt(cadena1.nextToken());
        }

        System.out.println("Ingrese las segundas coordenadas");
        cadena2 = new StringTokenizer(scanner.nextLine());

        x2 = Float.parseFloat(cadena2.nextToken());
        y2 = Float.parseFloat(cadena2.nextToken());
        z2 = Integer.parseInt(cadena2.nextToken());

        while ((x2 <= -100000 || x2 >= 100000) || (y2 <= -100000 || y2 >= 100000) || (z2 < 0 || z2 >= 100000)) {
            System.out.println("Coordenadas incorrectas, vuelva a ingresar");
            cadena1 = new StringTokenizer(scanner.nextLine());

            x2 = Float.parseFloat(cadena1.nextToken());
            y2 = Float.parseFloat(cadena1.nextToken());
            z2 = Integer.parseInt(cadena1.nextToken());
        }
        double distanciaPuntos = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

        int radios = z1 + z2;

        if (distanciaPuntos <= radios) {
            System.out.println("SI");
        } else {
            System.out.println("NO");
        }

        scanner.close();
    }
}
