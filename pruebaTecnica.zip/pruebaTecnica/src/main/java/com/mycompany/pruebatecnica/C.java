/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebatecnica;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author nicolaseduardoperalta
 */
public class C {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de productos");
        int t = scanner.nextInt();
        List<String> cadena = new ArrayList<String>();
        for (int i = 0; i < t; i++) {
            System.out.println("Ingrese la cantidad y valor del producto");
            int x = scanner.nextInt();
            int y = scanner.nextInt();
            int resultado = x * y;

            while ((x < 0 || x > 100000) || (y < 0 || y > 100000)) {
                System.out.println("Vuelva a ingresar la cantidad y valor del producto");
                x = scanner.nextInt();
                y = scanner.nextInt();
            }

            if (resultado >= 10000 && resultado <= 99999) {
                cadena.add("NO");
            } else {
                cadena.add("SI");
            }
        }
        for (String i : cadena) {
            System.out.println(i);
        }
        scanner.close();
    }
}
