/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebatecnica;

import java.util.Scanner;

/**
 *
 * @author nicolaseduardoperalta
 */
public class D {
 public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el numero");
        int x = scanner.nextInt();
        int cuadrado = (int) Math.pow(x, 2);
        
        if (x == cuadrado%10){
            System.out.println("SI");
        }else{
            System.out.println("NO");
        }
        scanner.close();
 }
}
